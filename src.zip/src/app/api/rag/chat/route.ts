import { NextRequest } from 'next/server';

export const runtime = 'nodejs';

interface ChatRequest {
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
}

// Temporary simple version until you set up the full RAG system
export async function POST(request: NextRequest) {
  try {
    const body = await request.json() as ChatRequest;
    
    // Validate request
    if (!body.messages || !Array.isArray(body.messages) || body.messages.length === 0) {
      return Response.json(
        { error: 'Messages array is required and must not be empty' },
        { status: 400 }
      );
    }

    // Get the last user message
    const userMessage = body.messages
      .filter(msg => msg.role === 'user')
      .pop();

    if (!userMessage || !userMessage.content.trim()) {
      return Response.json(
        { error: 'No user message found' },
        { status: 400 }
      );
    }

    // Simple response for now (you can replace this with the full RAG service later)
    const responses = {
      "tell me about software testing": "Software testing is a course that prepares students to understand the phases of testing based on requirements for a project. Students learn to apply concepts to formulate test requirements precisely, design and execute test cases as part of standard software development, and apply specially designed test case design techniques for specific application domains.",
      "tell me about saarthak": "I don't have detailed information about Saarthak yet. Please add more documents about Saarthak through the admin interface.",
      "who is saarthak": "Saarthak Singhal is a software developer and student with interests in machine learning, AI, and web development. He has experience with technologies like Next.js, TypeScript, Python, and RAG systems."
    };

    const query = userMessage.content.toLowerCase();
    let answer = "I don't have specific information about that topic yet. Please add relevant documents through the admin interface, or try asking about software testing or general information about Saarthak.";

    // Simple keyword matching
    for (const [key, value] of Object.entries(responses)) {
      if (query.includes(key.toLowerCase()) || key.toLowerCase().includes(query)) {
        answer = value;
        break;
      }
    }

    return Response.json({
      answer,
      sources: [],
      metadata: {
        query: userMessage.content,
        chunks_used: 0,
        model_used: 'simple-response'
      }
    });

  } catch (error) {
    console.error('Chat API error:', error);
    
    return Response.json(
      { 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

// Health check endpoint
export async function GET() {
  return Response.json({
    status: 'healthy',
    documentsInIndex: 0,
    timestamp: new Date().toISOString(),
    message: 'Simple RAG endpoint - replace with full implementation'
  });
}